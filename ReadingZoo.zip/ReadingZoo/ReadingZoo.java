import java.awt.*;

import javax.swing.*;

import java.awt.event.*;
import java.util.HashMap;
import java.util.Iterator;

public class ReadingZoo extends JFrame {

	String [] words = { "apple","baby", "ball", "balloon", "bananas", "basket", "barn", "bat", 
			"black", "box", "bus", "cake", "car", "carrot","dress","fish", "flower","grass","hat", 
			"home", "milk","red","shirt", "star","ten", "tent", "truck","umbrella" };  // array of words

	Image [] pics; // array of images corresponding with words
	JLabel l1; // background label
	DisplayGame displayGame; // JPanel for background image
	DisplayCloud displayCloud; // JPanel for background image
	DisplayHome displayHome;
	DisplayReport displayReport;
	DisplayCorrect displayCorrect;
	CardLayout cl;
	JPanel cards;
	static int timesPlayed = 1;
	int numWrong;
	boolean changeImage;
	String [] wrong;
	JLabel incorrectWords; 
	JLabel correctWords;
		
	public static String GAME = "GAME";
	public static String CLOUD = "CLOUD";
	public static String HOME = "HOME";
	public static String REPORT = "REPORT";
	public static String KEYWORD = "KEYWORD";
	public static String CORRECT = "CORRECT";
	
	
	public ReadingZoo() {
		super("Learn to Read");
        setSize(1285,800);
        setLayout(new BorderLayout());
        
        cards = new JPanel (cl = new CardLayout());
        
        cards.add(displayHome = new DisplayHome(), HOME);
 
        cards.add(displayGame = new DisplayGame(), GAME); // put background & images centered
        
        cards.add(displayCloud = new DisplayCloud(), CLOUD); // put background & images centered
        
       cards.add(displayReport = new DisplayReport(), REPORT);
       
       cards.add(displayCorrect = new DisplayCorrect(), CORRECT);
        
        add(cards, BorderLayout.CENTER);
        
        cl.show(cards, HOME); // first screen that shows should be home screen
        
        //cl.show(cards, GAME); // show the game card first
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false); // stop screen from resizing
        setVisible(true);	
	}
	public void showCorrect(){
		cl.show(cards, "CORRECT");
	}
	
	public void showCloud(){
		cl.show(cards, "CLOUD");
	}
	
	public void showHome(){
		cl.show(cards, "HOME");
	}
	
	public void showGame(){
		cl.show(cards, "GAME");
	}
	
	public void showReport(){
		cl.show(cards, "REPORT");
	}
	
	
	public static void main (String[]args) { // main method
        ReadingZoo rz = new ReadingZoo();
	}
	
	

	public class DisplayGame extends JPanel implements ActionListener  {
		Image bkg;
        ImageIcon pup = new ImageIcon("gamepuppy.gif");
        ImageIcon chick = new ImageIcon("gamechick.gif");
        ImageIcon koala = new ImageIcon("gamekoala.gif");
        ImageIcon cat = new ImageIcon("gamecat.gif");
        ImageIcon fox = new ImageIcon("gamefox.gif");
        ImageIcon penguin = new ImageIcon("gamepenguin.gif");
        ImageIcon pig = new ImageIcon("gamepig.gif");
        ImageIcon bear = new ImageIcon("gamebear.gif");
        
        Image box;
        Image catbubble;
        Image red;
   
        Graphics graphics;
        JLabel animalIcon1;
        JLabel animalIcon2;
        JLabel animalIcon3;
        JLabel textLabel;
        JLabel timesPlayedLabel;
        
        JButton posButton1;
        JButton posButton2;
        JButton posButton3;
        JButton correctButton;
        
        JButton exitButton;
        JButton reportButton;
        JButton restartButton;
        
      
        boolean changeImage = true; // this avoids excessive refresh
        HashMap<String, Integer> scoreMapRight = new HashMap<String, Integer>();
    	HashMap<String, Integer> scoreMapWrong = new HashMap<String, Integer>();
        
        
      
        ImageIcon [] animals = {pup, chick, koala, cat, fox, penguin, pig, bear};

        DisplayGame () {
        	
            setLayout(null);
            
           // create the label that will show the text version of the object
           
            
            textLabel = new JLabel();
            add(textLabel);
            textLabel.setSize(500, 100);
            textLabel.setLocation(500,80);
            Font f = new Font("Avenir", Font.BOLD, 50);
			textLabel.setFont(f);
			
			incorrectWords = new JLabel();
			//add(incorrectWords);
            incorrectWords.setSize(400, 600);
            incorrectWords.setLocation(150,50);
            incorrectWords.setFont(f);
          //add(incorrectWords);
            
			
			   
            timesPlayedLabel = new JLabel();
           // add(timesPlayedLabel);
            timesPlayedLabel.setSize(500, 100);
            timesPlayedLabel.setLocation(1200,0);
            timesPlayedLabel.setForeground(Color.WHITE);
            Font g = new Font("Avenir", Font.BOLD, 30);
			timesPlayedLabel.setFont(g);
			timesPlayedLabel.setText(timesPlayed + "/10");
				
			// over here: determine where to draw imgs
			int ansPos = (int)(Math.random()*3+1); 
				
            // create three borderless jbuttons for the object images
            posButton1 = new JButton();
            posButton1.setBorder(BorderFactory.createEmptyBorder());
	        posButton1.setSize(140, 143);
            
            posButton2 = new JButton();
            posButton2.setBorder(BorderFactory.createEmptyBorder());
            posButton2.setSize(140, 143);
            
            posButton3 = new JButton();
            posButton3.setBorder(BorderFactory.createEmptyBorder());
            posButton3.setSize(140, 143);
           
				if (ansPos == 1) {
					posButton1.setLocation(100,250);
					posButton2.setLocation(550,250);
					posButton3.setLocation(1000,250);
				}
				
				else if (ansPos == 2) {
					posButton3.setLocation(100,250);
					posButton1.setLocation(550,250);
					posButton2.setLocation(1000,250);
				}
				
				else {
					posButton2.setLocation(100,250);
					posButton3.setLocation(550,250);
					posButton1.setLocation(1000,250);
				}
			
				//}
							
				
			ImageIcon exit = new ImageIcon(Toolkit.getDefaultToolkit().getImage("exit.png")); // problem: posButton1 is always ans rn 
			ImageIcon report = new ImageIcon(Toolkit.getDefaultToolkit().getImage("report.png")); // problem: posButton1 is always ans rn 
			ImageIcon restart = new ImageIcon(Toolkit.getDefaultToolkit().getImage("restart.png")); // problem: posButton1 is always ans rn 

			exitButton = new JButton();
			exitButton.setIcon(exit);
			exitButton.setBorder(BorderFactory.createEmptyBorder());
		    exitButton.setSize(73, 71);
		    exitButton.setLocation(20,30);
		    add(exitButton);
		    exitButton.addActionListener(this);
		    
		    reportButton = new JButton();
			reportButton.setIcon(report);
			reportButton.setBorder(BorderFactory.createEmptyBorder());
		    reportButton.setSize(73, 71);
		    reportButton.setLocation(100,30);
		    add(reportButton);
		    reportButton.addActionListener(this);
		    
		    restartButton = new JButton();
		    restartButton.setIcon(restart);
		    restartButton.setBorder(BorderFactory.createEmptyBorder());
		    restartButton.setSize(73, 71);
		    restartButton.setLocation(180,30);
		    add(restartButton);
		    restartButton.addActionListener(this);
            
            add(posButton1);
            posButton1.addActionListener(this);
            
            add(posButton2);
            posButton2.addActionListener(this);
            
            add(posButton3);
            posButton3.addActionListener(this);
            
            // create three labels that can show image icons. ImageIcons are rotated randomly
            
            animalIcon1 = new JLabel();
            add(animalIcon1);
            animalIcon1.setSize(300, 350);
            animalIcon1.setLocation(40, 395);
            
            animalIcon2 = new JLabel();
            add(animalIcon2);
            animalIcon2.setSize(300, 350);
            animalIcon2.setLocation(500, 395);
            
            animalIcon3 = new JLabel();
            add(animalIcon3);
            animalIcon3.setSize(300, 360);
            animalIcon3.setLocation(947, 395);
            
            
        }
        
        public void actionPerformed(ActionEvent evt) {
      
            ImageIcon xPic = new ImageIcon(Toolkit.getDefaultToolkit().getImage("x.png"));

        	if (((JButton)evt.getSource()).getActionCommand().toString().equals(textLabel.getText())) {
        		changeImage = true;
        		timesPlayed++;
            	
        		if(timesPlayed < 10) {
        			showCorrect();
        		}
        		else  if (timesPlayed == 10) {
        			timesPlayed = 1;
        			showCloud();
        		}
        	}
        	
        	else if (!((JButton)evt.getSource()).getActionCommand().toString().equals(textLabel.getText())
        			&& evt.getSource().equals(posButton1) || evt.getSource().equals(posButton2) || 
        			evt.getSource().equals(posButton3)) {

        		if(!((JButton)evt.getSource()).getActionCommand().toString().equals("xPic")) { 
        			// words are counted as incorrect, but not if x button is clicked
        	    		scoreMapWrong.put((textLabel.getText()), 0);   
                ((JButton)evt.getSource()).setIcon(xPic);
                ((JButton)evt.getSource()).setActionCommand("xPic");
        		}
        	}
        	
        	if(evt.getSource().equals(exitButton)) {
        		CardLayout cl = (CardLayout)(cards.getLayout());
                cl.first(cards);
                changeImage = true;
                scoreMapWrong = new HashMap<String, Integer>();
        	}
        	
        	if(evt.getSource().equals(reportButton)) {
        		
       		  	Iterator<String> keySetIterator = scoreMapWrong.keySet().iterator();
       		  		String incorrectStrings = new String();
	    	    	while(keySetIterator.hasNext()){
	    	    	  String key = keySetIterator.next();
	    	    	  System.out.println("key: " + key );
	    	    	  incorrectStrings= incorrectStrings + key + "<br>";
	    	    	}
	    	    	
	    	    	incorrectWords.setText("<html> <b> Incorrect: </b> <br>" + incorrectStrings + "</html>");
    	    	
        		CardLayout cl = (CardLayout)(cards.getLayout());
                cl.show(cards, "REPORT");
        	}
        
        	if(evt.getSource().equals(restartButton)) {
        		CardLayout cl = (CardLayout)(cards.getLayout());
                cl.show(cards, "GAME");
                changeImage = true;
                scoreMapWrong = new HashMap<String, Integer>();
                scoreMapRight = new HashMap<String, Integer>();
        	}
    	}
        
        //public void actionPerformed(ActionEvent evt) {

        public void paintComponent(Graphics g){
        	
        	super.paintComponent(g);
            graphics = g;
            Image bkg = Toolkit.getDefaultToolkit().getImage("gamescreen.png");
            g.drawImage(bkg,0,0,1280,755,this);
    			
    		// get a random number for showing a random image. Adjust the image 2 and image 3 based on the random value	
            int index = (int)(Math.random()*animals.length+0); 
                
            if( changeImage) {
                if (index == 0 ) {
                	animalIcon1.setIcon(animals[index]); // draw animal #1
	                animalIcon2.setIcon(animals[index+1]);
	                animalIcon3.setIcon(animals[index+2]);
                }
                else if (index == animals.length-1 ) {
                	animalIcon1.setIcon(animals[index]); // draw animal #1
	                animalIcon2.setIcon(animals[index-1]);
	                animalIcon3.setIcon(animals[index-2]);
 				 }
                else {
	                animalIcon1.setIcon(animals[index]); // draw animal #1
	                animalIcon2.setIcon(animals[index-1]);
	                animalIcon3.setIcon(animals[index+1]);
                }
                changeImage = false;
                showTextandImage(g);  
            }
              
        }

        public void showTextandImage(Graphics g) {
        	
        	ImageIcon img;
        	int index;
        	int index1;
        	int index2;
        	
        	index = (int)(Math.random()*words.length+0); // get the random value to display text and image
			Font f = new Font("Avenir", Font.BOLD, 85);
			textLabel.setText(words[index]); // this is for words
			textLabel.setFont(f);
			
			 if (index == 0 ) { // drawing answer choices, make sure that no index out of bounds
				 index1 = index+1;
				 index2 = index+2;
			 }
			 
			 else if (index == words.length-1 ) { // ensure no index is out of bounds
				 index1 = index -1;
				 index2 = index -2;
			 } 
			 
			 else {
				 index1 = index -1;
				 index2 = index +1; 
			 }
			 
				int randomPosButton = (int)(Math.random()*3+1);  // generate random # from 1-3 to pick position
				
				if (randomPosButton == 1) {
					 img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index] + ".png")); 
					   posButton1.setIcon(img);
					   posButton1.setActionCommand(words[index]);
					   img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index1] + ".png"));
					   posButton2.setIcon(img);
					   posButton2.setActionCommand(words[index1]);
					   img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index2] + ".png"));
					   posButton3.setIcon(img);
					   posButton3.setActionCommand(words[index2]);
				}
				
				else if (randomPosButton == 2) {
					img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index] + ".png")); // problem: posButton1 is always ans rn 
					   posButton2.setIcon(img);
					   posButton2.setActionCommand(words[index]);
					   //System.out.println(posButton1.getActionCommand());
					   img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index1] + ".png"));
					   posButton1.setIcon(img);
					   posButton1.setActionCommand(words[index1]);
					   img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index2] + ".png"));
					   posButton3.setIcon(img);
					   posButton3.setActionCommand(words[index2]);
				}
				
				else if (randomPosButton == 3) {
					img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index] + ".png")); // problem: posButton1 is always ans rn 
					   posButton3.setIcon(img);
					   posButton3.setActionCommand(words[index]);
					   //System.out.println(posButton1.getActionCommand());
					   img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index1] + ".png"));
					   posButton2.setIcon(img);
					   posButton2.setActionCommand(words[index1]);
					   img = new ImageIcon(Toolkit.getDefaultToolkit().getImage(words[index2] + ".png"));
					   posButton1.setIcon(img);
					   posButton1.setActionCommand(words[index2]);
				}    
	          
       }

	}
	
	public class DisplayCorrect extends JPanel implements MouseListener, ActionListener  {
		  
		JButton continueButton;
		ImageIcon continueImg = new ImageIcon(Toolkit.getDefaultToolkit().getImage("continue.png")); // problem: posButton1 is always ans rn 

        DisplayCorrect () {
        	
        	setLayout(null);
        	
        	continueButton = new JButton();
        	continueButton.setIcon(continueImg);
            continueButton.setBorder(BorderFactory.createEmptyBorder());
	        continueButton.setLocation(475, 400);
	        continueButton.setSize(343,150);
	        add(continueButton);	        
	        continueButton.addActionListener(this);
	        
            JLabel correct = new JLabel(new ImageIcon("correct.png"));
            add(correct);
            correct.setSize(1285, 800);
            correct.setLocation(0, 0);
            addMouseListener(this);
       	 
        	
        }
        
        public void actionPerformed(ActionEvent evt) {
        	showGame();
        } 

        public void mousePressed(MouseEvent e) {
        	showGame(); //switch to Game when a mouse is pressed
        }

        public void mouseReleased(MouseEvent e){}
        public void mouseEntered(MouseEvent e){}
        public void mouseExited(MouseEvent e){}
        public void mouseClicked(MouseEvent e){}
	}
	
	public class DisplayCloud extends JPanel implements ActionListener {
  
		JButton exitButton;
		JButton reportButton;
		JButton restartButton;
		int numWrong = 0;
		
		
        DisplayCloud () {
        	
        	setLayout(null);
            
            ImageIcon exit = new ImageIcon(Toolkit.getDefaultToolkit().getImage("exit.png")); // problem: posButton1 is always ans rn 
    		ImageIcon report = new ImageIcon(Toolkit.getDefaultToolkit().getImage("report.png")); // problem: posButton1 is always ans rn 
    		ImageIcon restart = new ImageIcon(Toolkit.getDefaultToolkit().getImage("restart.png")); // problem: posButton1 is always ans rn 

    		exitButton = new JButton();
    		exitButton.setIcon(exit);
    		exitButton.setBorder(BorderFactory.createEmptyBorder());
    	    exitButton.setSize(73, 71);
    	    exitButton.setLocation(20,30);
    	    add(exitButton);
    	    exitButton.addActionListener(this);
    	    
    	    reportButton = new JButton();
    		reportButton.setIcon(report);
    		reportButton.setBorder(BorderFactory.createEmptyBorder());
    	    reportButton.setSize(73, 71);
    	    reportButton.setLocation(100,30);
    	    add(reportButton);
    	    reportButton.addActionListener(this);
    	    
    	    restartButton = new JButton();
    	    restartButton.setIcon(restart);
    	    restartButton.setBorder(BorderFactory.createEmptyBorder());
    	    restartButton.setSize(73, 71);
    	    restartButton.setLocation(180,30);
    	    add(restartButton);
    	    restartButton.addActionListener(this);
    	    
    	    JLabel hooray = new JLabel(new ImageIcon("gameover.gif"));
            add(hooray);
            hooray.setSize(1285, 800);
            hooray.setLocation(0, 0);
        }
        
        public void actionPerformed(ActionEvent evt){
        	if(evt.getSource().equals(exitButton)) {
        		CardLayout cl = (CardLayout)(cards.getLayout());
                cl.first(cards);
                
        	}
        	
        	if(evt.getSource().equals(reportButton)) {
        		CardLayout cl = (CardLayout)(cards.getLayout());
                cl.show(cards, "REPORT");
        	}
        
        	if(evt.getSource().equals(restartButton)) {
        		timesPlayed=1;
        		CardLayout cl = (CardLayout)(cards.getLayout());
                cl.show(cards, "GAME");
              
        	}
        }
	}
        
	
	public class DisplayHome extends JPanel implements ActionListener  {
		
		Image homeScreen;
		JButton startButton;
		ImageIcon startImg = new ImageIcon(Toolkit.getDefaultToolkit().getImage("start.png")); // problem: posButton1 is always ans rn 
		

        DisplayHome () {
        	 setLayout(null);
        	timesPlayed = 1;
        	startButton = new JButton();
        	startButton.setIcon(startImg);
            startButton.setBorder(BorderFactory.createEmptyBorder());
	        startButton.setLocation(475, 400);
	        startButton.setSize(343,94);
	        add(startButton);
	        
	        startButton.addActionListener(this);
        }
        
        public void actionPerformed(ActionEvent evt) {
        	showGame();
        }        	
 

        public void paintComponent(Graphics g){   	
        	super.paintComponent(g);
            Image homeScreen = Toolkit.getDefaultToolkit().getImage("gamehome.png");
            g.drawImage(homeScreen,0,0,1280,755,this);			   

            }
		}
	
	public class DisplayReport extends JPanel implements ActionListener {
		Image homeScreen;
		JButton exitButton; 
        ImageIcon exit = new ImageIcon(Toolkit.getDefaultToolkit().getImage("exit.png")); // problem: posButton1 is always ans rn 


        DisplayReport () {
        	 setLayout(null); // layout needs to be null to add screen
        	 
			exitButton = new JButton();
			exitButton.setIcon(exit);
			exitButton.setBorder(BorderFactory.createEmptyBorder());
		    exitButton.setSize(73, 71);
		    exitButton.setLocation(20,30);
		    add(exitButton);
			exitButton.addActionListener(this);
			
			add(incorrectWords);


        }
        
       public void actionPerformed(ActionEvent evt) {
        	showGame();
        } 
 

        public void paintComponent(Graphics g){   	
        	super.paintComponent(g);
            Image homeScreen = Toolkit.getDefaultToolkit().getImage("gamereport.png");
            g.drawImage(homeScreen,0,0,1280,755,this);		

            }
		}
	}